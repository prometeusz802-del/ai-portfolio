SZYMON WAC — AI CREATIVE PORTFOLIO

The website is ready to publish as a static site.

FASTEST WAY TO GET A PUBLIC LINK:
1. Keep index.html and the assets folder together.
2. Upload the whole folder to a static website host (for example Netlify Drop).
3. The host will give you a public URL that you can paste into the ElevenLabs portfolio field.

You can also use GitHub Pages, Cloudflare Pages or any normal web host.

Important: do not upload index.html alone. The assets folder contains the portfolio images.
